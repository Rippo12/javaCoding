package hust.soict.globalict.aims.utils;

public class RunMyDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyDate a= new  MyDate();
		a.acceptDate();
		a.printDate();
	}

}

